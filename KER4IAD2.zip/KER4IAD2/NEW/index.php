// Simple Hello World echo
<?php

echo "Hello World!";
