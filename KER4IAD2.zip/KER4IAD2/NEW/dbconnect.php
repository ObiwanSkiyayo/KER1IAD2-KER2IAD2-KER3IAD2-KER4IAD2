// Set connection information

<?php
    
    $MyUsername = "bastiaan";  // mysql gebruikersnaam
    $MyPassword = "Ub7ujeiX4o";  // mysql wachtwoord
    $MyHostname = "localhost";      // dit is meestal "localhost" tenzij mysql op een andere server staat
    
    $dbh = mysql_pconnect($MyHostname , $MyUsername, $MyPassword);
    $selected = mysql_select_db("bastiaan",$dbh);

?>
