// This is the gas section, to gt only the gas data. If you're looking for the temp data please look for "dataTemp.php"
// I didnt work with the header include in this. This was a fault of mine and in the future this will not be the case.

<?php
    
    $MyUsername = "bastiaan";  // mysql gebruikersnaam
    $MyPassword = "Ub7ujeiX4o";  // mysql wachtwoord
    $MyHostname = "localhost";      // dit is meestal "localhost" tenzij mysql op een andere server staat
    
    $con=mysqli_connect("localhost",$MyUsername,$MyPassword,"bastiaan");
    
    // Check connection if it fails echo "Failed.."
    if (mysqli_connect_error())
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    
    // Select needed queries.
    $query2 = "SELECT peak,id,event FROM gas ORDER BY id DESC LIMIT 20";


    $result2 = mysqli_query($con,$query2);
    
    // Set rows as an array, so we can fill the results
    $rows = array();
    
    while($r = mysqli_fetch_array($result2)) {
        $rows[] = $r;
    }
    
    // Print it out to JSON format, so we can split it us to readable chucks so ChartJS can work with it.
    print json_encode($rows);
    
    // Close connection
    mysqli_close($con);
?>
