// Here we process the data received from the arduino.
// "Location: review_data.php" is not being used anymore and can be ignored

<?php
    // Setup a MySQL connection
    include("dbconnect.php");
    
    if (empty($_GET["temperature"])){
        // no data passed by get so dont add it.
    } else {
        // Data is beign passed.
        // Prepare the SQL statement temperatur.
        $SQL1 = "INSERT INTO bastiaan.temperature (sensor ,celsius) VALUES ('".$_GET["serialone"]."', '".$_GET["temperature"]."')" ;
    
        // Execute SQL statement
        mysql_query($SQL1);
    }
    
    
    if (empty($_GET["gas"])) {
        // no data passed by get
    } else {
        // Data is being passed
        // Prepare the SQL statement gas
        $SQL2 = "INSERT INTO bastiaan.gas (sensor ,peak) VALUES ('".$_GET["serialtwo"]."', '".$_GET["gas"]."')";
        
        // Execute SQL statement
        mysql_query($SQL2);
    }
    
    
    // Please ignore
    header("Location: review_data.php");
?>

