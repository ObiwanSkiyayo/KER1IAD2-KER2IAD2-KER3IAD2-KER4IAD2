// Not being used, this was suppose to be a warning. If the garbage can was overfilled a light will light up on the arduino.
// Work in progress

<?php
    $MyUsername = "bastiaan";  // mysql gebruikersnaam
    $MyPassword = "Ub7ujeiX4o";  // mysql wachtwoord
    $MyHostname = "localhost";      // dit is meestal "localhost" tenzij mysql op een andere server staat
    
    $con=mysqli_connect("localhost",$MyUsername,$MyPassword,"bastiaan");
    
    // Retrieve mysql records
    $query1 = "SELECT peak FROM gas ORDER BY id DESC";
    
    $result1 = mysqli_query($con,$query1);
    
    $rows = array();
    while($r = mysqli_fetch_array($result1)) {
        $rows[] = $r;
    }
    
    
    print json_encode($rows);
    
?>
