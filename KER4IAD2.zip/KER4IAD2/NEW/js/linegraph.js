// This is where the GraphJS magic happens.

$(document).ready(function(){
// Graph 1, Celsius sensor.
	$.ajax({
        // Set readable url, with the json data.
		url : "http://studenthome.hku.nl/~Bastiaan.Burghardt/iot/dataTemp.php",
        // GET function, because we need to GET
		type : "GET",
		success : function(rows){
			console.log(rows);

           // Parse the JSON data created in dataGas.php and dataTemp.php
            data = JSON.parse(rows);
           
			var userid = [];
			var celsius_data= [];
			var time_data = [];

           // Fill data
			for(var i in data) {
				userid.push(data[i].event);
				celsius_data.push(data[i].celsius);
				time_data.push(data[i].id);
			}
           
           // Chartdata for temp, which in turn GraphJS outputs to a nice graph.
			var chartdata = {
				labels: userid,
				datasets: [
					{
						label: "Celsius",
						fill: true,
						lineTension: 0.4,
						backgroundColor: "rgba(255, 245, 0, 0.30)",
						borderColor: "rgba(230, 230, 0, 0.75)",
						pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
						pointHoverBorderColor: "rgba(59, 89, 152, 1)",
                        // Set the dataset.
						data: celsius_data
					}
				]
			};
           
           // Select which canvas needed to be used, this is defined within Linegraph.HTML
           var ctx = $("#mycanvas");
           
           // Extra options to custumize GraphJS.
           var options = {
           scales: {
           yAxes: [{
                   display: true,
                   ticks: {
                   suggestedMax: 40,    // minimum will be 0, unless there is a lower value.
                   // OR //
                   beginAtZero: true   // minimum value will be 0.
                   }
                   }]
           }}
           // Create the chart.
           var LineGraph1 = new Chart(ctx, {
                type: 'line',
                // Select which chartdata it needs to be displayed.
				data: chartdata,
                options:options
           });
           
           
		},
        // If we encounter an error, do this:
		error : function(data) {

		}
	});
                  
                  
// Graph 2, Gas sensor, please read the comments above if stuck.
  $.ajax({
         
         url : "http://studenthome.hku.nl/~Bastiaan.Burghardt/iot/dataGas.php",
         type : "GET",
         success : function(rows){
         console.log(rows);
         
         data = JSON.parse(rows);
         
         var userid = [];
         var peak_data = [];
         var time_data = [];
         
         for(var i in data) {
         userid.push(data[i].event);
         peak_data.push(data[i].peak);
         time_data.push(data[i].id);
         }
         

         var chartdata2 = {
         labels: userid,
         datasets: [
                    {
                    label: "Gas Peak",
                    fill: true,
                    lineTension: 0.4,
                    backgroundColor: "rgba(30, 100, 0, 0.30)",
                    borderColor: "rgba(20, 80, 152, 1)",
                    pointHoverBackgroundColor: "rgba(59, 89, 152, 1)",
                    pointHoverBorderColor: "rgba(59, 89, 152, 1)",
                    data: peak_data
                    }
                    ]
         
         };
         
         
         var ctx2 = $("#mycanvas2");
         
         var options = {
         scales: {
         yAxes: [{
                 display: true,
                 ticks: {
                 suggestedMin: 200,
                 suggestedMax: 400    // minimum will be 0, unless there is a lower value.
                 // OR //
                 //beginAtZero: true   // minimum value will be 0.
                 }
                 }]
         }}
         
         var LineGraph2 = new Chart(ctx2, {
                                    type: 'line',
                                    data: chartdata2,
                                    options: options
                                    });
         
         },
         error : function(data) {
         
         }
         });
});


