// This is currently not in use anymore. You can still visit the site by going to this adress:
// http://studenthome.hku.nl/~Bastiaan.Burghardt/review_data.php
// Bastiaan Burghardt
// 3016389

<?php
    // Start MySQL Verbinding
    include('dbconnect.php');
?>

<html>
<head>
// Title of the webpage.
<title>Arduino Temperature/Size Log</title>
// Settings some styles
<style type="text/css">
.table_titles, .table_cells_odd, .table_cells_even {
    padding-right: 20px;
    padding-left: 20px;
color: #000;
}
.table_titles {
color: #FFF;
    background-color: #666;
}
// we will work with even and odd cells, so you can clearly see the difference.
.table_cells_odd {
    background-color: #CCC;
}
.table_cells_even {
    background-color: #FAFAFA;
}
table {
border: 2px solid #333;
}
// Set font.
body { font-family: "Trebuchet MS", Arial; }
</style>
</head>

<body>
// Title visible on the site.
<h1>Arduino Data Log</h1>
<table border="0" cellspacing="0" cellpadding="4">
// Create table for the data to be put in.
<tr>
<td class="table_titles">ID</td>
<td class="table_titles">Date and Time</td>
<td class="table_titles">Sensor Serial</td>
<td class="table_titles">Data</td>
</tr>


<?php
    // Retrieve all records and display them
    $result1 = mysql_query("SELECT * FROM temperature ORDER BY id DESC");
    $result2 = mysql_query("SELECT * FROM gas ORDER BY id DESC");
    
    // Used for row color toggle
    $oddrow = true;
    
    // process every record TEMP data
    while( $row = mysql_fetch_array($result1) )
    {
        // Switch between the row classes.
        if ($oddrow)
        {
            $css_class=' class="table_cells_odd"';
        }
        else
        {
            $css_class=' class="table_cells_even"';
        }
        
        $oddrow = !$oddrow;
        
        // Echo the data in to the corresponding rows.
        echo '<tr>';
        echo '   <td'.$css_class.'>'.$row["id"].'</td>';
        echo '   <td'.$css_class.'>'.$row["event"].'</td>';
        echo '   <td'.$css_class.'>'.$row["sensor"].'</td>';
        echo '   <td'.$css_class.'>'.$row["celsius"].'</td>';
        echo '</tr>';
    }
    
    // process every record GAS data
    while( $row = mysql_fetch_array($result2) )
    {
        // Switch between the row classes.
        if ($oddrow)
        {
            $css_class=' class="table_cells_odd"';
        }
        else
        {
            $css_class=' class="table_cells_even"';
        }
        
        $oddrow = !$oddrow;
        // Same goes for here.
        echo '<tr>';
        echo '   <td'.$css_class.'>'.$row["id"].'</td>';
        echo '   <td'.$css_class.'>'.$row["event"].'</td>';
        echo '   <td'.$css_class.'>'.$row["sensor"].'</td>';
        echo '   <td'.$css_class.'>'.$row["peak"].'</td>';
        echo '</tr>';
    }
    ?>
</table>
</body>
</html>
