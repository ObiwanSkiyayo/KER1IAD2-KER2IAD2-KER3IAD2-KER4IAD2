// This is currently not in use anymore. please visit the folder "NEW"
// Bastiaan Burghardt
// 3016389

<?php
    // Connect to MySQL library
    include("dbconnect.php");
    
    if (empty($_GET["temperature"])){
        // no data passed by get so dont add it. In the past i used to get blank readings.
    } else {
        // Data is beign passed.
        // Prepare the SQL statement temperatur.
        $SQL1 = "INSERT INTO bastiaan.temperature (sensor ,celsius) VALUES ('".$_GET["serialone"]."', '".$_GET["temperature"]."')" ;
    
        // Execute SQL statement
        mysql_query($SQL1);
    }
    
    
    if (empty($_GET["gas"])) {
        // no data passed by get
    } else {
        // Data is being passed
        // Prepare the SQL statement gas
        $SQL2 = "INSERT INTO bastiaan.gas (sensor ,peak) VALUES ('".$_GET["serialtwo"]."', '".$_GET["gas"]."')";
        
        // Execute SQL statement
        mysql_query($SQL2);
    }
    
    
    // Go to the review_data.php (optional)
    header("Location: review_data.php");
?>

