// This is currently not in use anymore. please visit the folder "NEW"
// Bastiaan Burghardt
// 3016389


<?php
    
    $MyUsername = "bastiaan";  // mysql gebruikersnaam
    $MyPassword = "Ub7ujeiX4o";  // mysql wachtwoord
    $MyHostname = "localhost";      // dit is meestal "localhost" tenzij mysql op een andere server staat
    
    // Connect here
    $dbh = mysql_pconnect($MyHostname , $MyUsername, $MyPassword);
    $selected = mysql_select_db("bastiaan",$dbh);

?>
